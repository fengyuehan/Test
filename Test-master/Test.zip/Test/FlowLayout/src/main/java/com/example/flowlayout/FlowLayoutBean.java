package com.example.flowlayout;

public class FlowLayoutBean {
    private String tv;

    public String getTv() {
        return tv;
    }

    public void setTv(String tv) {
        this.tv = tv;
    }
}
