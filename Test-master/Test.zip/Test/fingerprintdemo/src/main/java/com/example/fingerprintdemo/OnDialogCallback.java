package com.example.fingerprintdemo;

public interface OnDialogCallback {
    void onSure();
    void onCancel();
    void onDialogDismiss();
}
