package com.example.lettersidebar;

/**
 * @author zzf
 * @date 2019/7/23/023
 * 描述：
 */
public class ItemBean {
    private String name;


    public ItemBean(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
