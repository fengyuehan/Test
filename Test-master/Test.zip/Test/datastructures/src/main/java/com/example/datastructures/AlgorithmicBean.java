package com.example.datastructures;

/**
 * @ClassName AlgorithmicBean
 * @Description TODO
 * @Author user
 * @Date 2019/9/6
 * @Version 1.0
 */
public class AlgorithmicBean {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
