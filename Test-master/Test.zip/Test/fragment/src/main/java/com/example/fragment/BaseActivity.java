package com.example.fragment;

import androidx.appcompat.app.AppCompatActivity;

/**
 * @ClassName BaseActivity
 * @Description TODO
 * @Author user
 * @Date 2019/12/2
 * @Version 1.0
 */
public class BaseActivity extends AppCompatActivity {
}
