package com.example.lettersidebar;

/**
 * @author zzf
 * @date 2019/7/25/025
 * 描述：
 */
public interface SlideBarTouchListener {
    void onTouch(String letter, boolean isTouch);
}
